/*
Bridge file - Connect App.js (First Component)
with index.html (Web Page)
*/
import ReactDOM from 'react-dom/client';
import App from './App';
const div = document.getElementById('root');
const root = ReactDOM.createRoot(div);
root.render(<App/>)
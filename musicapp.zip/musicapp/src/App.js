// This is a First Component

import Songs from "./components/Songs";

/*
Component is just a Function prefer is arrow
*/
const App = ()=>{
  return (
  <Songs/>
  );
}
export default App;